# Exemplo 6 - Textura Atlas Colisão

# Use as teclas WASD para mover o jogador
import pygame, sys
from pygame.locals import QUIT
from typing import KeysView
pygame.init()

pygame.key
pygame.mouse


hero_walk = [] # vetor de imagens
hero_anim_frame = 1
hero_pos_x = 5
hero_pos_y = 325
hero_anim_time = 0 # variavel para controle do tempo da animação
offset=0



clock = pygame.time.Clock()
width = 800 
height = 600
tileset = None
pos_x = 5
pos_y = 325
vel = 0.1
mapa_plataforma = [
  "XXXXXXXXXXXXXX",
  "XXXXXXXXXXXXXX",
  "XXXXXXXXXXXXXX",
  "XXXXXXXXXXXXXX",
  "XXXXXXXXXXXXXX",
  "XXXBXXXXXXXXXX",
  "XXBBBXXXXXXXXX",
  "GGGGGGGAAGGGGG",
  "TTTTTTTPPTTTTT",
  "TTTTTTTPPTTTTT",
]


def load():
  global tileset, collider_jogador, collider_mapa, collider_caixaB, collider_caixaC, collider_mapa2, clock, hero_walk
  tileset = pygame.image.load("platform_tileset.png")
  collider_mapa = pygame.Rect(0, 448, 450, 200)
  collider_mapa2 = pygame.Rect(575, 448, 450, 100)
  collider_caixaB = pygame.Rect(125, 385, 195, 70)
  collider_caixaC = pygame.Rect(190, 320, 70, 70)
  clock = pygame.time.Clock()
  for i in range(1, 17): #carrega as imagens da animação
      hero_walk.append(pygame.image.load("Hero_Walk_0" + str(i) + ".png"))

def update(dt):
  global pos_x, pos_y, collider_jogador, vel, hero_walk, hero_anim_frame, hero_pos_x,hero_pos_y, hero_anim_time, offset, old_hero_pos_x, old_hero_pos_y
  keys = pygame.key.get_pressed()
  old_x, old_y = pos_x, pos_y

  old_hero_pos_x, old_hero_pos_y = hero_pos_x, hero_pos_y
  if keys[pygame.K_RIGHT]:
      offset=0
      hero_pos_x = hero_pos_x + (0.1 * dt) # movimenta o personagem
      hero_anim_time = hero_anim_time + dt #incrementa o tempo usando dt
      if hero_anim_time > 100: #quando acumular mais de 100 ms
          hero_anim_frame = hero_anim_frame + 1 # avança para proximo frame
          if hero_anim_frame > 3: # loop da animação
              hero_anim_frame = 0
          hero_anim_time = 0 #reinicializa a contagem do tempo
          offset=0

          

  if keys[pygame.K_LEFT]:
    offset=4
    hero_pos_x = hero_pos_x + (-0.1 * dt) # movimenta o personagem
    hero_anim_time = hero_anim_time + dt #incrementa o tempo usando dt
    if hero_anim_time > 100: #quando acumular mais de 100 ms
        hero_anim_frame = hero_anim_frame + 1 # avança para proximo frame
        if hero_anim_frame > 3: # loop da animação
            hero_anim_frame = 0
        hero_anim_time = 0 #reinicializa a contagem do tempo
        offset=4


  if keys[pygame.K_UP]:
    offset=8
    hero_pos_y = hero_pos_y - (0.1 * dt) # movimenta o personagem
    hero_anim_time = hero_anim_time + dt #incrementa o tempo usando dt
    if hero_anim_time > 100: #quando acumular mais de 100 ms
        hero_anim_frame = hero_anim_frame + 1 # avança para proximo frame
        if hero_anim_frame > 3: # loop da animação
              hero_anim_frame = 0
        hero_anim_time = 0 #reinicializa a contagem do tempo
        offset=8
 


  if keys[pygame.K_DOWN]:
    offset=12
    hero_pos_y = hero_pos_y + (0.1 * dt) # movimenta o personagem
    hero_anim_time = hero_anim_time + dt #incrementa o tempo usando dt
    if hero_anim_time > 100: #quando acumular mais de 100 ms
        hero_anim_frame = hero_anim_frame + 1 # avança para proximo frame
        if hero_anim_frame > 3: # loop da animação
            hero_anim_frame = 0
        hero_anim_time = 0 #reinicializa a contagem do tempo
        offset=12
  
  collider_jogador = pygame.Rect(hero_pos_x + 40, hero_pos_y, 50, 125)

  if collider_jogador.colliderect(collider_mapa):
    hero_pos_x = old_hero_pos_x
    hero_pos_y = old_hero_pos_y
  if collider_jogador.colliderect(collider_mapa2):
    hero_pos_x = old_hero_pos_x
    hero_pos_y = old_hero_pos_y
  if collider_jogador.colliderect(collider_caixaB):
    hero_pos_x = old_hero_pos_x
    hero_pos_y = old_hero_pos_y
  if collider_jogador.colliderect(collider_caixaC):
    hero_pos_x = old_hero_pos_x
    hero_pos_y = old_hero_pos_y

def draw_screen(screen):
  screen.fill((152,209,250))
  # Mapa plataforma
  for i, linha in enumerate(mapa_plataforma):
    for j, char in enumerate(linha):
      if char == "B":
        screen.blit(tileset, (j*64, i*64), (0, 128, 64, 64))
      elif char == "G":
        screen.blit(tileset, (j*64, i*64), (0, 0, 64, 64))
      elif char == "T":
        screen.blit(tileset, (j*64, i*64), (64, 0, 64, 64))
      elif char == "A":
        screen.blit(tileset, (j*64, i*64), (128, 0, 64, 64))
      elif char == "P":
        screen.blit(tileset, (j*64, i*64), (128, 64, 64, 64))
  
  screen.blit(hero_walk[hero_anim_frame+offset], (hero_pos_x, hero_pos_y))

  # Collider personagem
  pygame.draw.rect(screen, (0, 255, 0), (collider_jogador.x, collider_jogador.y, collider_jogador.width, collider_jogador.height), 2)
  # colider mapa
  pygame.draw.rect(screen, (0, 255, 0), (collider_mapa.x, collider_mapa.y , collider_mapa.width, collider_mapa.height), 2)
  # colider mapa
  pygame.draw.rect(screen, (0, 255, 0), (collider_mapa2.x, collider_mapa2.y , collider_mapa2.width, collider_mapa2.height), 2)
  # colider caixa
  pygame.draw.rect(screen, (0, 255, 0), (collider_caixaB.x, collider_caixaB.y , collider_caixaB.width, collider_caixaB.height), 2)
  # colider caixa
  pygame.draw.rect(screen, (0, 255, 0), (collider_caixaC.x, collider_caixaC.y , collider_caixaC.width, collider_caixaC.height), 2)

#####################################################
# A PRINCIPIO NÃO PRECISA ALTERAR DAQUI PRA BAIXO   #
#####################################################
def main_loop(screen):  
    global clock
    running = True
    while running:
        for e in pygame.event.get(): 
            if e.type == pygame.QUIT: # fechamento do prog
                running = False
                break

        # Define FPS máximo
        clock.tick(60)
        # Tempo transcorrido desde a última atualização 
        dt = clock.get_time()
        # Atualiza posição dos objetos
        update(dt)
        # Desenha objetos
        draw_screen(screen)
        # Pygame atualiza a visualização da tela
        pygame.display.update()

# Programa principal
pygame.init()
screen = pygame.display.set_mode((width, height))
load()
main_loop(screen)
pygame.quit()